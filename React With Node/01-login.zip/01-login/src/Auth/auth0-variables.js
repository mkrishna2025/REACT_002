export const AUTH_CONFIG = {
  domain: 'mrksihna2025.auth0.com',
  clientId: 'YUEkI6OAxiyxT2TQZLLwx6YuULO1unjh',
  callbackUrl: 'http://localhost:3000/callback'
}
